-- -------------------------------------------
resteasy+spring框架
纯接口项目/前后台交互的项目
日志
无dao层实现
文件读取，文件上传服务器，页面文件上传
过滤器
统一异常处理
数据源切换读写
service事务处理
----------------------------------------------
https://www.cnblogs.com/yue31313/p/7277662.html?utm_source=itdadao&utm_medium=referral
码云的使用