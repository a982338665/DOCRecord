package pers.lishbo.aservice.abstractservice;

/**
 * 公共service抽象类
 *
 */
public abstract class ImportA implements GanSuService {

}
