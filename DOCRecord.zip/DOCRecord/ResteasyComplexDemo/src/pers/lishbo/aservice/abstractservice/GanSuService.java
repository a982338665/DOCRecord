package pers.lishbo.aservice.abstractservice;

public interface GanSuService {

	String testkind();

}
