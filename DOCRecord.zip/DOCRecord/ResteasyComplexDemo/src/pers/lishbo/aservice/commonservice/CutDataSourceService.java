package pers.lishbo.aservice.commonservice;


public interface CutDataSourceService {

	String findSchool(String string);

	String findurl(String string);

	
}