package pers.lishbo.abean;

import java.util.Date;

public class SchoolBean {
    private String cSid;

    private String cInnersid;

    private String cAreaid;

    private String cAreaname;

    private String cCityid;

    private String cCityname;

    private String cName;

    private Short cIsprimary;

    private Short cEdusysp;

    private Short cIsjunior;

    private Short cEdusysj;

    private Short cSenior;

    private Integer cEdusyss;

    private Short cIsuniversity;

    private Short cEdusysu;

    private String cEname;

    private String cOrgancode;

    private String cMasterid;

    private String cMastername;

    private String cPartyid;

    private String cPartyname;

    private Date cCreateday;

    private Date cHappyday;

    private String cSuppername;

    private String cSchoolpro;

    private String cSchoolca;

    private String cSchool;

    private String cProvince;

    private String cCity;

    private String cCountry;

    private String cProvincecode;

    private String cCitycode;

    private String cCountrycode;

    private String cStreet;

    private String cGateno;

    private Long cZipno;

    private String cAreacode;

    private String cAreaca;

    private String cEconomics;

    private String cNation;

    private String cStuarea;

    private String cEdusys;

    private String cMainlug;

    private String cSeclug;

    private String cTel;

    private String cMob;

    private String cWeb;

    private String cTwitter;

    private String cCyhonor;

    private Date cCyhonordate;

    private String cCyhonordep;

    private String cCyhonorcode;

    private String cCyhonorcash;

    private String cCyhonorreson;

    private String cCyhonorsumarry;

    private String cEmergemcy;

    private String cEmergemcytel;

    private String cEmergencyeocc;

    private String cHisevolution;

    private Short cIsuse;

    private Date cCreatetime;

    private String cLogopath;

    private String cDesc;

    private String cMail;

    private String cFaxmail;

    private String cSuppercode;

    private String cAreasuppername;

    private String cAreasuppercode;

    private Short cIsminority;

    private String cMasterphone;

    private String cLongitude;

    private String cLatitude;

    private Short cBoarding;

    private String cLegalpersoncode;

    private String cFormpeoplemail;

    private String cElevation;

    private Short cLandtype;

    private String cLandcode;

    private Integer cAttachclasstype;

    private String cRecurit;

    private String cUpdatorid;

    private Date cUpdatetime;

    private String cOptip;

    private Short cIskindergarten;

    private Short cEdusysk;

    private String cFeetype;

    public String getcSid() {
        return cSid;
    }

    public void setcSid(String cSid) {
        this.cSid = cSid;
    }

    public String getcInnersid() {
        return cInnersid;
    }

    public void setcInnersid(String cInnersid) {
        this.cInnersid = cInnersid;
    }

    public String getcAreaid() {
        return cAreaid;
    }

    public void setcAreaid(String cAreaid) {
        this.cAreaid = cAreaid;
    }

    public String getcAreaname() {
        return cAreaname;
    }

    public void setcAreaname(String cAreaname) {
        this.cAreaname = cAreaname;
    }

    public String getcCityid() {
        return cCityid;
    }

    public void setcCityid(String cCityid) {
        this.cCityid = cCityid;
    }

    public String getcCityname() {
        return cCityname;
    }

    public void setcCityname(String cCityname) {
        this.cCityname = cCityname;
    }

    public String getcName() {
        return cName;
    }

    public void setcName(String cName) {
        this.cName = cName;
    }

    public Short getcIsprimary() {
        return cIsprimary;
    }

    public void setcIsprimary(Short cIsprimary) {
        this.cIsprimary = cIsprimary;
    }

    public Short getcEdusysp() {
        return cEdusysp;
    }

    public void setcEdusysp(Short cEdusysp) {
        this.cEdusysp = cEdusysp;
    }

    public Short getcIsjunior() {
        return cIsjunior;
    }

    public void setcIsjunior(Short cIsjunior) {
        this.cIsjunior = cIsjunior;
    }

    public Short getcEdusysj() {
        return cEdusysj;
    }

    public void setcEdusysj(Short cEdusysj) {
        this.cEdusysj = cEdusysj;
    }

    public Short getcSenior() {
        return cSenior;
    }

    public void setcSenior(Short cSenior) {
        this.cSenior = cSenior;
    }

    public Integer getcEdusyss() {
        return cEdusyss;
    }

    public void setcEdusyss(Integer cEdusyss) {
        this.cEdusyss = cEdusyss;
    }

    public Short getcIsuniversity() {
        return cIsuniversity;
    }

    public void setcIsuniversity(Short cIsuniversity) {
        this.cIsuniversity = cIsuniversity;
    }

    public Short getcEdusysu() {
        return cEdusysu;
    }

    public void setcEdusysu(Short cEdusysu) {
        this.cEdusysu = cEdusysu;
    }

    public String getcEname() {
        return cEname;
    }

    public void setcEname(String cEname) {
        this.cEname = cEname;
    }

    public String getcOrgancode() {
        return cOrgancode;
    }

    public void setcOrgancode(String cOrgancode) {
        this.cOrgancode = cOrgancode;
    }

    public String getcMasterid() {
        return cMasterid;
    }

    public void setcMasterid(String cMasterid) {
        this.cMasterid = cMasterid;
    }

    public String getcMastername() {
        return cMastername;
    }

    public void setcMastername(String cMastername) {
        this.cMastername = cMastername;
    }

    public String getcPartyid() {
        return cPartyid;
    }

    public void setcPartyid(String cPartyid) {
        this.cPartyid = cPartyid;
    }

    public String getcPartyname() {
        return cPartyname;
    }

    public void setcPartyname(String cPartyname) {
        this.cPartyname = cPartyname;
    }

    public Date getcCreateday() {
        return cCreateday;
    }

    public void setcCreateday(Date cCreateday) {
        this.cCreateday = cCreateday;
    }

    public Date getcHappyday() {
        return cHappyday;
    }

    public void setcHappyday(Date cHappyday) {
        this.cHappyday = cHappyday;
    }

    public String getcSuppername() {
        return cSuppername;
    }

    public void setcSuppername(String cSuppername) {
        this.cSuppername = cSuppername;
    }

    public String getcSchoolpro() {
        return cSchoolpro;
    }

    public void setcSchoolpro(String cSchoolpro) {
        this.cSchoolpro = cSchoolpro;
    }

    public String getcSchoolca() {
        return cSchoolca;
    }

    public void setcSchoolca(String cSchoolca) {
        this.cSchoolca = cSchoolca;
    }

    public String getcSchool() {
        return cSchool;
    }

    public void setcSchool(String cSchool) {
        this.cSchool = cSchool;
    }

    public String getcProvince() {
        return cProvince;
    }

    public void setcProvince(String cProvince) {
        this.cProvince = cProvince;
    }

    public String getcCity() {
        return cCity;
    }

    public void setcCity(String cCity) {
        this.cCity = cCity;
    }

    public String getcCountry() {
        return cCountry;
    }

    public void setcCountry(String cCountry) {
        this.cCountry = cCountry;
    }

    public String getcProvincecode() {
        return cProvincecode;
    }

    public void setcProvincecode(String cProvincecode) {
        this.cProvincecode = cProvincecode;
    }

    public String getcCitycode() {
        return cCitycode;
    }

    public void setcCitycode(String cCitycode) {
        this.cCitycode = cCitycode;
    }

    public String getcCountrycode() {
        return cCountrycode;
    }

    public void setcCountrycode(String cCountrycode) {
        this.cCountrycode = cCountrycode;
    }

    public String getcStreet() {
        return cStreet;
    }

    public void setcStreet(String cStreet) {
        this.cStreet = cStreet;
    }

    public String getcGateno() {
        return cGateno;
    }

    public void setcGateno(String cGateno) {
        this.cGateno = cGateno;
    }

    public Long getcZipno() {
        return cZipno;
    }

    public void setcZipno(Long cZipno) {
        this.cZipno = cZipno;
    }

    public String getcAreacode() {
        return cAreacode;
    }

    public void setcAreacode(String cAreacode) {
        this.cAreacode = cAreacode;
    }

    public String getcAreaca() {
        return cAreaca;
    }

    public void setcAreaca(String cAreaca) {
        this.cAreaca = cAreaca;
    }

    public String getcEconomics() {
        return cEconomics;
    }

    public void setcEconomics(String cEconomics) {
        this.cEconomics = cEconomics;
    }

    public String getcNation() {
        return cNation;
    }

    public void setcNation(String cNation) {
        this.cNation = cNation;
    }

    public String getcStuarea() {
        return cStuarea;
    }

    public void setcStuarea(String cStuarea) {
        this.cStuarea = cStuarea;
    }

    public String getcEdusys() {
        return cEdusys;
    }

    public void setcEdusys(String cEdusys) {
        this.cEdusys = cEdusys;
    }

    public String getcMainlug() {
        return cMainlug;
    }

    public void setcMainlug(String cMainlug) {
        this.cMainlug = cMainlug;
    }

    public String getcSeclug() {
        return cSeclug;
    }

    public void setcSeclug(String cSeclug) {
        this.cSeclug = cSeclug;
    }

    public String getcTel() {
        return cTel;
    }

    public void setcTel(String cTel) {
        this.cTel = cTel;
    }

    public String getcMob() {
        return cMob;
    }

    public void setcMob(String cMob) {
        this.cMob = cMob;
    }

    public String getcWeb() {
        return cWeb;
    }

    public void setcWeb(String cWeb) {
        this.cWeb = cWeb;
    }

    public String getcTwitter() {
        return cTwitter;
    }

    public void setcTwitter(String cTwitter) {
        this.cTwitter = cTwitter;
    }

    public String getcCyhonor() {
        return cCyhonor;
    }

    public void setcCyhonor(String cCyhonor) {
        this.cCyhonor = cCyhonor;
    }

    public Date getcCyhonordate() {
        return cCyhonordate;
    }

    public void setcCyhonordate(Date cCyhonordate) {
        this.cCyhonordate = cCyhonordate;
    }

    public String getcCyhonordep() {
        return cCyhonordep;
    }

    public void setcCyhonordep(String cCyhonordep) {
        this.cCyhonordep = cCyhonordep;
    }

    public String getcCyhonorcode() {
        return cCyhonorcode;
    }

    public void setcCyhonorcode(String cCyhonorcode) {
        this.cCyhonorcode = cCyhonorcode;
    }

    public String getcCyhonorcash() {
        return cCyhonorcash;
    }

    public void setcCyhonorcash(String cCyhonorcash) {
        this.cCyhonorcash = cCyhonorcash;
    }

    public String getcCyhonorreson() {
        return cCyhonorreson;
    }

    public void setcCyhonorreson(String cCyhonorreson) {
        this.cCyhonorreson = cCyhonorreson;
    }

    public String getcCyhonorsumarry() {
        return cCyhonorsumarry;
    }

    public void setcCyhonorsumarry(String cCyhonorsumarry) {
        this.cCyhonorsumarry = cCyhonorsumarry;
    }

    public String getcEmergemcy() {
        return cEmergemcy;
    }

    public void setcEmergemcy(String cEmergemcy) {
        this.cEmergemcy = cEmergemcy;
    }

    public String getcEmergemcytel() {
        return cEmergemcytel;
    }

    public void setcEmergemcytel(String cEmergemcytel) {
        this.cEmergemcytel = cEmergemcytel;
    }

    public String getcEmergencyeocc() {
        return cEmergencyeocc;
    }

    public void setcEmergencyeocc(String cEmergencyeocc) {
        this.cEmergencyeocc = cEmergencyeocc;
    }

    public String getcHisevolution() {
        return cHisevolution;
    }

    public void setcHisevolution(String cHisevolution) {
        this.cHisevolution = cHisevolution;
    }

    public Short getcIsuse() {
        return cIsuse;
    }

    public void setcIsuse(Short cIsuse) {
        this.cIsuse = cIsuse;
    }

    public Date getcCreatetime() {
        return cCreatetime;
    }

    public void setcCreatetime(Date cCreatetime) {
        this.cCreatetime = cCreatetime;
    }

    public String getcLogopath() {
        return cLogopath;
    }

    public void setcLogopath(String cLogopath) {
        this.cLogopath = cLogopath;
    }

    public String getcDesc() {
        return cDesc;
    }

    public void setcDesc(String cDesc) {
        this.cDesc = cDesc;
    }

    public String getcMail() {
        return cMail;
    }

    public void setcMail(String cMail) {
        this.cMail = cMail;
    }

    public String getcFaxmail() {
        return cFaxmail;
    }

    public void setcFaxmail(String cFaxmail) {
        this.cFaxmail = cFaxmail;
    }

    public String getcSuppercode() {
        return cSuppercode;
    }

    public void setcSuppercode(String cSuppercode) {
        this.cSuppercode = cSuppercode;
    }

    public String getcAreasuppername() {
        return cAreasuppername;
    }

    public void setcAreasuppername(String cAreasuppername) {
        this.cAreasuppername = cAreasuppername;
    }

    public String getcAreasuppercode() {
        return cAreasuppercode;
    }

    public void setcAreasuppercode(String cAreasuppercode) {
        this.cAreasuppercode = cAreasuppercode;
    }

    public Short getcIsminority() {
        return cIsminority;
    }

    public void setcIsminority(Short cIsminority) {
        this.cIsminority = cIsminority;
    }

    public String getcMasterphone() {
        return cMasterphone;
    }

    public void setcMasterphone(String cMasterphone) {
        this.cMasterphone = cMasterphone;
    }

    public String getcLongitude() {
        return cLongitude;
    }

    public void setcLongitude(String cLongitude) {
        this.cLongitude = cLongitude;
    }

    public String getcLatitude() {
        return cLatitude;
    }

    public void setcLatitude(String cLatitude) {
        this.cLatitude = cLatitude;
    }

    public Short getcBoarding() {
        return cBoarding;
    }

    public void setcBoarding(Short cBoarding) {
        this.cBoarding = cBoarding;
    }

    public String getcLegalpersoncode() {
        return cLegalpersoncode;
    }

    public void setcLegalpersoncode(String cLegalpersoncode) {
        this.cLegalpersoncode = cLegalpersoncode;
    }

    public String getcFormpeoplemail() {
        return cFormpeoplemail;
    }

    public void setcFormpeoplemail(String cFormpeoplemail) {
        this.cFormpeoplemail = cFormpeoplemail;
    }

    public String getcElevation() {
        return cElevation;
    }

    public void setcElevation(String cElevation) {
        this.cElevation = cElevation;
    }

    public Short getcLandtype() {
        return cLandtype;
    }

    public void setcLandtype(Short cLandtype) {
        this.cLandtype = cLandtype;
    }

    public String getcLandcode() {
        return cLandcode;
    }

    public void setcLandcode(String cLandcode) {
        this.cLandcode = cLandcode;
    }

    public Integer getcAttachclasstype() {
        return cAttachclasstype;
    }

    public void setcAttachclasstype(Integer cAttachclasstype) {
        this.cAttachclasstype = cAttachclasstype;
    }

    public String getcRecurit() {
        return cRecurit;
    }

    public void setcRecurit(String cRecurit) {
        this.cRecurit = cRecurit;
    }

    public String getcUpdatorid() {
        return cUpdatorid;
    }

    public void setcUpdatorid(String cUpdatorid) {
        this.cUpdatorid = cUpdatorid;
    }

    public Date getcUpdatetime() {
        return cUpdatetime;
    }

    public void setcUpdatetime(Date cUpdatetime) {
        this.cUpdatetime = cUpdatetime;
    }

    public String getcOptip() {
        return cOptip;
    }

    public void setcOptip(String cOptip) {
        this.cOptip = cOptip;
    }

    public Short getcIskindergarten() {
        return cIskindergarten;
    }

    public void setcIskindergarten(Short cIskindergarten) {
        this.cIskindergarten = cIskindergarten;
    }

    public Short getcEdusysk() {
        return cEdusysk;
    }

    public void setcEdusysk(Short cEdusysk) {
        this.cEdusysk = cEdusysk;
    }

    public String getcFeetype() {
        return cFeetype;
    }

    public void setcFeetype(String cFeetype) {
        this.cFeetype = cFeetype;
    }

	@Override
	public String toString() {
		return "SchoolBean [cSid=" + cSid + ", cInnersid=" + cInnersid
				+ ", cAreaid=" + cAreaid + ", cAreaname=" + cAreaname
				+ ", cCityid=" + cCityid + ", cCityname=" + cCityname
				+ ", cName=" + cName + ", cIsprimary=" + cIsprimary
				+ ", cEdusysp=" + cEdusysp + ", cIsjunior=" + cIsjunior
				+ ", cEdusysj=" + cEdusysj + ", cSenior=" + cSenior
				+ ", cEdusyss=" + cEdusyss + ", cIsuniversity=" + cIsuniversity
				+ ", cEdusysu=" + cEdusysu + ", cEname=" + cEname
				+ ", cOrgancode=" + cOrgancode + ", cMasterid=" + cMasterid
				+ ", cMastername=" + cMastername + ", cPartyid=" + cPartyid
				+ ", cPartyname=" + cPartyname + ", cCreateday=" + cCreateday
				+ ", cHappyday=" + cHappyday + ", cSuppername=" + cSuppername
				+ ", cSchoolpro=" + cSchoolpro + ", cSchoolca=" + cSchoolca
				+ ", cSchool=" + cSchool + ", cProvince=" + cProvince
				+ ", cCity=" + cCity + ", cCountry=" + cCountry
				+ ", cProvincecode=" + cProvincecode + ", cCitycode="
				+ cCitycode + ", cCountrycode=" + cCountrycode + ", cStreet="
				+ cStreet + ", cGateno=" + cGateno + ", cZipno=" + cZipno
				+ ", cAreacode=" + cAreacode + ", cAreaca=" + cAreaca
				+ ", cEconomics=" + cEconomics + ", cNation=" + cNation
				+ ", cStuarea=" + cStuarea + ", cEdusys=" + cEdusys
				+ ", cMainlug=" + cMainlug + ", cSeclug=" + cSeclug + ", cTel="
				+ cTel + ", cMob=" + cMob + ", cWeb=" + cWeb + ", cTwitter="
				+ cTwitter + ", cCyhonor=" + cCyhonor + ", cCyhonordate="
				+ cCyhonordate + ", cCyhonordep=" + cCyhonordep
				+ ", cCyhonorcode=" + cCyhonorcode + ", cCyhonorcash="
				+ cCyhonorcash + ", cCyhonorreson=" + cCyhonorreson
				+ ", cCyhonorsumarry=" + cCyhonorsumarry + ", cEmergemcy="
				+ cEmergemcy + ", cEmergemcytel=" + cEmergemcytel
				+ ", cEmergencyeocc=" + cEmergencyeocc + ", cHisevolution="
				+ cHisevolution + ", cIsuse=" + cIsuse + ", cCreatetime="
				+ cCreatetime + ", cLogopath=" + cLogopath + ", cDesc=" + cDesc
				+ ", cMail=" + cMail + ", cFaxmail=" + cFaxmail
				+ ", cSuppercode=" + cSuppercode + ", cAreasuppername="
				+ cAreasuppername + ", cAreasuppercode=" + cAreasuppercode
				+ ", cIsminority=" + cIsminority + ", cMasterphone="
				+ cMasterphone + ", cLongitude=" + cLongitude + ", cLatitude="
				+ cLatitude + ", cBoarding=" + cBoarding
				+ ", cLegalpersoncode=" + cLegalpersoncode
				+ ", cFormpeoplemail=" + cFormpeoplemail + ", cElevation="
				+ cElevation + ", cLandtype=" + cLandtype + ", cLandcode="
				+ cLandcode + ", cAttachclasstype=" + cAttachclasstype
				+ ", cRecurit=" + cRecurit + ", cUpdatorid=" + cUpdatorid
				+ ", cUpdatetime=" + cUpdatetime + ", cOptip=" + cOptip
				+ ", cIskindergarten=" + cIskindergarten + ", cEdusysk="
				+ cEdusysk + ", cFeetype=" + cFeetype + "]";
	}
    
}