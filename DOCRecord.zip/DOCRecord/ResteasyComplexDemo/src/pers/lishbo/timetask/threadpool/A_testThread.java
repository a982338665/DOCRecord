package pers.lishbo.timetask.threadpool;
/**
 * 模拟webservice：另起一个线程执行单独的任务
 * @author lishengbo
 * @Time 2017年12月2日下午1:34:46
 */
public class A_testThread {

	public static void main(String[] args) {
		new A_shili1().start();
	}
}
