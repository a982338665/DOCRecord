package pers.lishbo.timetask.threadlocal;

public class test {

	 test() {
		// TODO Auto-generated constructor stub
	}
/*	public test(String name) {
		super();
		this.name = name;
	}*/

	 public  static String nn="";
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
class sds{
	public static void main(String[] args) {
//		test.
//		test dd=new test();
//		System.out.println(dd.getName());
	}
}