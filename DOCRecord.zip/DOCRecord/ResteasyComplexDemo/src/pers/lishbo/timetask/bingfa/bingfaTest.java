package pers.lishbo.timetask.bingfa;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * java5的线程并发库
 * AtomicInteger:--对整数操作时,不受其他线程影响,一般作为共享变量时候考虑
 * 		多线程中，先对整数加，然后取出来，取得过程中其他线程对它进行加，就会导致取出来的结果并非自己想要的
 * 		故，使用此类，使线程安全
 * @author lishengbo
 * @Time 2017年12月2日下午12:20:49
 */
public class bingfaTest {

	
	public static void main(String[] args) {
		
	}
	
	
	
	
}
