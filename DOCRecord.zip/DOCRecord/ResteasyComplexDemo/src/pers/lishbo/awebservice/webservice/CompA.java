package pers.lishbo.awebservice.webservice;



/**
 * 公共组件抽象类
 *
 */

public abstract class CompA implements IComp {
	
	@Override
	public String testKind() {
		// TODO Auto-generated method stub
		return null;
	}
}
