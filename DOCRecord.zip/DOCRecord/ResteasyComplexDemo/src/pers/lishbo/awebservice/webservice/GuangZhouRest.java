package pers.lishbo.awebservice.webservice;

import org.springframework.stereotype.Component;

/**
 * 甘肃
 */

@Component("GuangZhouRest")
public class GuangZhouRest extends CompA {

	
	
}
