package pers.lishbo.awebservice.webservice;



/**
 * 通用接口组件接口
 *
 */
public interface IComp {

	String testKind();
	
}
