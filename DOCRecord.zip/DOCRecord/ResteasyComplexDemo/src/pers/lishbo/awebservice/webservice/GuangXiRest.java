package pers.lishbo.awebservice.webservice;

import org.springframework.stereotype.Component;

/**
 * 甘肃
 */

@Component("GuangXiRest")
public class GuangXiRest extends CompA {

	
	@Override
	public String testKind() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
