package pers.lishbo.util.jsontojson;

public class ResultUserExtDatatBean {

	private String TeaThirdUserId;
	private String PareThirdUserId;
	public String getTeaThirdUserId() {
		return TeaThirdUserId;
	}
	public void setTeaThirdUserId(String teaThirdUserId) {
		TeaThirdUserId = teaThirdUserId;
	}
	public String getPareThirdUserId() {
		return PareThirdUserId;
	}
	public void setPareThirdUserId(String pareThirdUserId) {
		PareThirdUserId = pareThirdUserId;
	}
	
}
